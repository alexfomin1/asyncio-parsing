list_of_links = (
    {"name": "РБК", "url": "https://rssexport.rbc.ru/rbcnews/news/20/full.rss"},
    {"name": "ТАСС", "url": "http://tass.ru/rss/anews.xml?sections=NDczMA%3D%3D"},
    {"name": "Интерфакс", "url": "https://rss.interfax.ru/"},
    {"name": "Ведомости", "url": "https://www.vedomosti.ru/rss/articles"},
    {"name": "Коммерсантъ", "url": "https://www.kommersant.ru/rss/main.xml"},
)
