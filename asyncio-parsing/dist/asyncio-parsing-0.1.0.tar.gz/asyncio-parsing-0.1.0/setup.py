# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['asyncio_parsing']

package_data = \
{'': ['*']}

install_requires = \
['aiocouch>=2.2.2,<3.0.0',
 'aiodns>=3.0.0,<4.0.0',
 'aiohttp>=3.8.3,<4.0.0',
 'aioredis>=2.0.1,<3.0.0',
 'asyncio>=3.4.3,<4.0.0',
 'feedparser>=6.0.10,<7.0.0',
 'loguru>=0.6.0,<0.7.0',
 'pydantic>=1.10.2,<2.0.0',
 'pytest>=7.2.0,<8.0.0']

setup_kwargs = {
    'name': 'asyncio-parsing',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'alex',
    'author_email': 'me@fomin3.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
